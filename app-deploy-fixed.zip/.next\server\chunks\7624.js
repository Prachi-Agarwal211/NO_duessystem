"use strict";exports.id=7624,exports.ids=[7624],exports.modules={7624:(e,t,r)=>{r.d(t,{pB:()=>S,$F:()=>N,Cz:()=>k,sendReapplicationNotifications:()=>P});var n=Object.defineProperty,i=Object.defineProperties,s=Object.getOwnPropertyDescriptors,o=Object.getOwnPropertySymbols,a=Object.prototype.hasOwnProperty,l=Object.prototype.propertyIsEnumerable,c=(e,t,r)=>t in e?n(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,d=(e,t)=>{for(var r in t||(t={}))a.call(t,r)&&c(e,r,t[r]);if(o)for(var r of o(t))l.call(t,r)&&c(e,r,t[r]);return e},u=(e,t)=>i(e,s(t)),p=(e,t,r)=>new Promise((n,i)=>{var s=e=>{try{a(r.next(e))}catch(e){i(e)}},o=e=>{try{a(r.throw(e))}catch(e){i(e)}},a=e=>e.done?n(e.value):Promise.resolve(e.value).then(s,o);a((r=r.apply(e,t)).next())}),h=class{constructor(e){this.resend=e}create(e){return p(this,arguments,function*(e,t={}){return yield this.resend.post("/api-keys",e,t)})}list(){return p(this,null,function*(){return yield this.resend.get("/api-keys")})}remove(e){return p(this,null,function*(){return yield this.resend.delete(`/api-keys/${e}`)})}},f=class{constructor(e){this.resend=e}create(e){return p(this,arguments,function*(e,t={}){return yield this.resend.post("/audiences",e,t)})}list(){return p(this,null,function*(){return yield this.resend.get("/audiences")})}get(e){return p(this,null,function*(){return yield this.resend.get(`/audiences/${e}`)})}remove(e){return p(this,null,function*(){return yield this.resend.delete(`/audiences/${e}`)})}};function m(e){var t;return{attachments:null==(t=e.attachments)?void 0:t.map(e=>({content:e.content,filename:e.filename,path:e.path,content_type:e.contentType,content_id:e.contentId})),bcc:e.bcc,cc:e.cc,from:e.from,headers:e.headers,html:e.html,reply_to:e.replyTo,scheduled_at:e.scheduledAt,subject:e.subject,tags:e.tags,text:e.text,to:e.to}}var g=class{constructor(e){this.resend=e}send(e){return p(this,arguments,function*(e,t={}){return this.create(e,t)})}create(e){return p(this,arguments,function*(e,t={}){let n=[];for(let t of e){if(t.react){if(!this.renderAsync)try{let{renderAsync:e}=yield Promise.all([r.e(6938),r.e(9800),r.e(4067),r.e(4830),r.e(5182),r.e(5296)]).then(r.bind(r,97044));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}t.html=yield this.renderAsync(t.react),t.react=void 0}n.push(m(t))}return yield this.resend.post("/emails/batch",n,t)})}},y=class{constructor(e){this.resend=e}create(e){return p(this,arguments,function*(e,t={}){if(e.react){if(!this.renderAsync)try{let{renderAsync:e}=yield Promise.all([r.e(6938),r.e(9800),r.e(4067),r.e(4830),r.e(5182),r.e(5296)]).then(r.bind(r,97044));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}e.html=yield this.renderAsync(e.react)}return yield this.resend.post("/broadcasts",{name:e.name,audience_id:e.audienceId,preview_text:e.previewText,from:e.from,html:e.html,reply_to:e.replyTo,subject:e.subject,text:e.text},t)})}send(e,t){return p(this,null,function*(){return yield this.resend.post(`/broadcasts/${e}/send`,{scheduled_at:null==t?void 0:t.scheduledAt})})}list(){return p(this,null,function*(){return yield this.resend.get("/broadcasts")})}get(e){return p(this,null,function*(){return yield this.resend.get(`/broadcasts/${e}`)})}remove(e){return p(this,null,function*(){return yield this.resend.delete(`/broadcasts/${e}`)})}update(e,t){return p(this,null,function*(){return yield this.resend.patch(`/broadcasts/${e}`,{name:t.name,audience_id:t.audienceId,from:t.from,html:t.html,text:t.text,subject:t.subject,reply_to:t.replyTo,preview_text:t.previewText})})}},b=class{constructor(e){this.resend=e}create(e){return p(this,arguments,function*(e,t={}){return yield this.resend.post(`/audiences/${e.audienceId}/contacts`,{unsubscribed:e.unsubscribed,email:e.email,first_name:e.firstName,last_name:e.lastName},t)})}list(e){return p(this,null,function*(){return yield this.resend.get(`/audiences/${e.audienceId}/contacts`)})}get(e){return p(this,null,function*(){return e.id||e.email?yield this.resend.get(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}update(e){return p(this,null,function*(){return e.id||e.email?yield this.resend.patch(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`,{unsubscribed:e.unsubscribed,first_name:e.firstName,last_name:e.lastName}):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}remove(e){return p(this,null,function*(){return e.id||e.email?yield this.resend.delete(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}},x=class{constructor(e){this.resend=e}create(e){return p(this,arguments,function*(e,t={}){return yield this.resend.post("/domains",{name:e.name,region:e.region,custom_return_path:e.customReturnPath},t)})}list(){return p(this,null,function*(){return yield this.resend.get("/domains")})}get(e){return p(this,null,function*(){return yield this.resend.get(`/domains/${e}`)})}update(e){return p(this,null,function*(){return yield this.resend.patch(`/domains/${e.id}`,{click_tracking:e.clickTracking,open_tracking:e.openTracking,tls:e.tls})})}remove(e){return p(this,null,function*(){return yield this.resend.delete(`/domains/${e}`)})}verify(e){return p(this,null,function*(){return yield this.resend.post(`/domains/${e}/verify`)})}},v=class{constructor(e){this.resend=e}send(e){return p(this,arguments,function*(e,t={}){return this.create(e,t)})}create(e){return p(this,arguments,function*(e,t={}){if(e.react){if(!this.renderAsync)try{let{renderAsync:e}=yield Promise.all([r.e(6938),r.e(9800),r.e(4067),r.e(4830),r.e(5182),r.e(5296)]).then(r.bind(r,97044));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}e.html=yield this.renderAsync(e.react)}return yield this.resend.post("/emails",m(e),t)})}get(e){return p(this,null,function*(){return yield this.resend.get(`/emails/${e}`)})}update(e){return p(this,null,function*(){return yield this.resend.patch(`/emails/${e.id}`,{scheduled_at:e.scheduledAt})})}cancel(e){return p(this,null,function*(){return yield this.resend.post(`/emails/${e}/cancel`)})}},w="undefined"!=typeof process&&process.env&&process.env.RESEND_BASE_URL||"https://api.resend.com",$="undefined"!=typeof process&&process.env&&process.env.RESEND_USER_AGENT||"resend-node:6.0.3";let E=new class{constructor(e){if(this.key=e,this.apiKeys=new h(this),this.audiences=new f(this),this.batch=new g(this),this.broadcasts=new y(this),this.contacts=new b(this),this.domains=new x(this),this.emails=new v(this),!e&&("undefined"!=typeof process&&process.env&&(this.key=process.env.RESEND_API_KEY),!this.key))throw Error('Missing API key. Pass it to the constructor `new Resend("re_123")`');this.headers=new Headers({Authorization:`Bearer ${this.key}`,"User-Agent":$,"Content-Type":"application/json"})}fetchRequest(e){return p(this,arguments,function*(e,t={}){try{let r=yield fetch(`${w}${e}`,t);if(!r.ok)try{let e=yield r.text();return{data:null,error:JSON.parse(e)}}catch(t){if(t instanceof SyntaxError)return{data:null,error:{name:"application_error",message:"Internal server error. We are unable to process your request right now, please try again later."}};let e={message:r.statusText,name:"application_error"};if(t instanceof Error)return{data:null,error:u(d({},e),{message:t.message})};return{data:null,error:e}}return{data:yield r.json(),error:null}}catch(e){return{data:null,error:{name:"application_error",message:"Unable to fetch data. The request could not be resolved."}}}})}post(e,t){return p(this,arguments,function*(e,t,r={}){let n=new Headers(this.headers);r.idempotencyKey&&n.set("Idempotency-Key",r.idempotencyKey);let i=d({method:"POST",headers:n,body:JSON.stringify(t)},r);return this.fetchRequest(e,i)})}get(e){return p(this,arguments,function*(e,t={}){let r=d({method:"GET",headers:this.headers},t);return this.fetchRequest(e,r)})}put(e,t){return p(this,arguments,function*(e,t,r={}){let n=d({method:"PUT",headers:this.headers,body:JSON.stringify(t)},r);return this.fetchRequest(e,n)})}patch(e,t){return p(this,arguments,function*(e,t,r={}){let n=d({method:"PATCH",headers:this.headers,body:JSON.stringify(t)},r);return this.fetchRequest(e,n)})}delete(e,t){return p(this,null,function*(){let r={method:"DELETE",headers:this.headers,body:JSON.stringify(t)};return this.fetchRequest(e,r)})}}(process.env.RESEND_API_KEY),_=process.env.RESEND_FROM_EMAIL||"JECRC No Dues <onboarding@resend.dev>",R=process.env.RESEND_REPLY_TO||"onboarding@resend.dev";async function k({to:e,subject:t,html:r,text:n}){try{if(!e||!t||!r)throw Error("Missing required email parameters");if(!process.env.RESEND_API_KEY)return console.warn("⚠️ RESEND_API_KEY not configured. Email not sent."),console.log(`📧 Mock Email - To: ${e}, Subject: ${t}`),{success:!1,error:"Resend API key not configured"};let{data:i,error:s}=await E.emails.send({from:_,to:Array.isArray(e)?e:[e],subject:t,html:r,text:n||r.replace(/<[^>]*>/g,"").replace(/&nbsp;/g," ").replace(/&/g,"&").replace(/</g,"<").replace(/>/g,">").trim(),reply_to:R});if(s)return console.error("❌ Email send error:",s),{success:!1,error:s.message};return console.log(`✅ Email sent successfully - ID: ${i.id}`),{success:!0,id:i.id}}catch(e){return console.error("❌ Email service error:",e),{success:!1,error:e.message}}}function A({title:e,content:t,actionUrl:r,actionText:n,footerText:i}){return`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${e}</title>
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #f5f5f5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <!-- Main Container -->
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); overflow: hidden;">
          
          <!-- Header with Logo -->
          <tr>
            <td style="background: linear-gradient(135deg, #dc2626 0%, #b91c1c 100%); padding: 30px; text-align: center;">
              <!-- JECRC Logo -->
              <img src="https://jecrc.ac.in/wp-content/uploads/2023/06/logo-1.png" alt="JECRC University" style="height: 60px; width: auto; margin-bottom: 15px; display: block; margin-left: auto; margin-right: auto;" />
              <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600;">
                JECRC University
              </h1>
              <p style="margin: 8px 0 0 0; color: rgba(255,255,255,0.9); font-size: 14px;">
                No Dues Clearance System
              </p>
            </td>
          </tr>

          <!-- Content -->
          <tr>
            <td style="padding: 40px 30px;">
              <h2 style="margin: 0 0 20px 0; color: #1f2937; font-size: 20px; font-weight: 600;">
                ${e}
              </h2>
              ${t}
              
              ${r&&n?`
                <table width="100%" cellpadding="0" cellspacing="0" style="margin-top: 30px;">
                  <tr>
                    <td align="center">
                      <a href="${r}" style="display: inline-block; background-color: #dc2626; color: #ffffff; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-weight: 600; font-size: 16px;">
                        ${n}
                      </a>
                    </td>
                  </tr>
                </table>
              `:""}
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background-color: #f9fafb; padding: 20px 30px; border-top: 1px solid #e5e7eb;">
              <p style="margin: 0; color: #6b7280; font-size: 12px; text-align: center;">
                ${i||"This is an automated email from JECRC No Dues System."}
              </p>
              <p style="margin: 8px 0 0 0; color: #9ca3af; font-size: 11px; text-align: center;">
                \xa9 ${new Date().getFullYear()} JECRC University. All rights reserved.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim()}async function N({departmentEmail:e,studentName:t,registrationNo:r,formId:n,dashboardUrl:i}){let s=A({title:"New No Dues Application",content:`
    <p style="margin: 0 0 16px 0; color: #374151; font-size: 15px; line-height: 1.6;">
      A new No Dues application has been submitted and requires your attention.
    </p>
    
    <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f9fafb; border-radius: 8px; padding: 20px; margin: 20px 0;">
      <tr>
        <td>
          <p style="margin: 0 0 8px 0; color: #6b7280; font-size: 13px; font-weight: 600; text-transform: uppercase;">
            Student Details
          </p>
          <p style="margin: 0 0 6px 0; color: #1f2937; font-size: 15px;">
            <strong>Name:</strong> ${t}
          </p>
          <p style="margin: 0; color: #1f2937; font-size: 15px;">
            <strong>Registration No:</strong> <span style="font-family: monospace; background-color: #fef2f2; padding: 2px 6px; border-radius: 4px; color: #dc2626;">${r}</span>
          </p>
        </td>
      </tr>
    </table>
    
    <p style="margin: 16px 0 0 0; color: #6b7280; font-size: 14px;">
      Please review the application and take appropriate action (Approve/Reject) from your dashboard.
    </p>
  `,actionUrl:i,actionText:"Review Application",footerText:"Please do not reply to this email. For support, contact support@jecrc.ac.in"});return k({to:e,subject:`New Application: ${t} (${r})`,html:s})}async function S({staffMembers:e,studentName:t,registrationNo:r,formId:n,dashboardUrl:i}){if(!e||0===e.length)return console.warn("⚠️ No staff members to notify"),[];console.log(`📧 Sending notifications to ${e.length} staff member(s)...`);let s=await Promise.allSettled(e.map(e=>N({departmentEmail:e.email,studentName:t,registrationNo:r,formId:n,dashboardUrl:i}))),o=s.filter(e=>"fulfilled"===e.status&&e.value.success).length;return console.log(`✅ ${o}/${e.length} notifications sent successfully`),s}async function P({staffMembers:e,studentName:t,registrationNo:r,studentMessage:n,reapplicationNumber:i,dashboardUrl:s,formUrl:o}){if(!e||0===e.length)return console.warn("⚠️ No staff members to notify for reapplication"),[];console.log(`📧 Sending reapplication notifications to ${e.length} staff member(s)...`);let a=A({title:"Student Reapplication - Review Required",content:`
    <p style="margin: 0 0 16px 0; color: #374151; font-size: 15px; line-height: 1.6;">
      A student has <strong>reapplied</strong> to their No Dues application after addressing the rejection reasons.
    </p>
    
    <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #fef3c7; border-radius: 8px; border-left: 4px solid #f59e0b; padding: 20px; margin: 20px 0;">
      <tr>
        <td>
          <p style="margin: 0 0 8px 0; color: #f59e0b; font-size: 16px; font-weight: 600;">
            🔄 Reapplication #${i}
          </p>
          <p style="margin: 0 0 6px 0; color: #1f2937; font-size: 15px;">
            <strong>Student:</strong> ${t}
          </p>
          <p style="margin: 0; color: #1f2937; font-size: 15px;">
            <strong>Registration No:</strong> <span style="font-family: monospace; background-color: #fef2f2; padding: 2px 6px; border-radius: 4px; color: #dc2626;">${r}</span>
          </p>
        </td>
      </tr>
    </table>
    
    <div style="background-color: #eff6ff; border-radius: 8px; padding: 20px; margin: 20px 0;">
      <p style="margin: 0 0 8px 0; color: #3b82f6; font-size: 13px; font-weight: 600; text-transform: uppercase;">
        Student's Response
      </p>
      <p style="margin: 0; color: #1e3a8a; font-size: 14px; line-height: 1.6; font-style: italic;">
        "${n}"
      </p>
    </div>
    
    <p style="margin: 16px 0 0 0; color: #6b7280; font-size: 14px;">
      The student has made corrections to their application. Please review the updated information and take appropriate action.
    </p>
  `,actionUrl:o||s,actionText:"Review Reapplication",footerText:"This is a reapplication. Previous rejection reasons should be addressed."}),l=await Promise.allSettled(e.map(e=>k({to:e.email,subject:`🔄 Reapplication: ${t} (${r}) - Review #${i}`,html:a}))),c=l.filter(e=>"fulfilled"===e.status&&e.value.success).length;return console.log(`✅ ${c}/${e.length} reapplication notifications sent successfully`),l}}};